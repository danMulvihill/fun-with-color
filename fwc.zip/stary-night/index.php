
<?php include("../header.php") ?>

    <div id="back"></div>
    <div class="moon"></div>
    
    <div class="star-1 stars"></div>
    <div class="star-2 stars"></div>
    <div class="star-3 stars"></div>

  </div>

  </body>
  </html>