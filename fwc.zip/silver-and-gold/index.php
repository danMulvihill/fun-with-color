<?php include("../header.php") ?>

<div id="medals">
    <div class="medal gold" ><p>Gold</p></div>
    <div class="medal silver">Silver</div>
    <div class="medal bronze">Bronze</div>
</div>

<div class="stripes"></div>

</div>

</body>
</html>